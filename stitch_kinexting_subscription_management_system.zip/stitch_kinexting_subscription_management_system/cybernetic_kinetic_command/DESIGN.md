---
name: Cybernetic Kinetic Command
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d8'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#918fa1'
  outline-variant: '#464555'
  surface-tint: '#c3c0ff'
  primary: '#c3c0ff'
  on-primary: '#1d00a5'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#4d44e3'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#d2bbff'
  on-tertiary: '#3f008e'
  tertiary-container: '#7531e6'
  on-tertiary-container: '#e4d4ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d2bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#5a00c6'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
  obsidian-base: '#060c18'
  obsidian-card: '#0f172a'
  obsidian-surface: '#111827'
  border-dark: '#334155'
  border-light: '#e2e8f0'
  cyber-cyan-bright: '#22d3ee'
  cyber-cyan-hover: '#0284c7'
  indigo-hover: '#4338ca'
  accent-emerald: '#10b981'
  accent-destructive: '#ef4444'
  text-dark-primary: '#e2e8f0'
  text-dark-muted: '#94a3b8'
  text-light-primary: '#020817'
  text-light-muted: '#64748b'
typography:
  display:
    fontFamily: Inter
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 62px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-performance mission-critical interface for autonomous agent workflows, enterprise CRM orchestration, and live financial infrastructure. Drawing heavily from **Cybernetic Modernism** with subtle high-fidelity tactical cues, the aesthetic balances the rigor of institutional SaaS platforms with the kinetic, responsive feel of automated intelligence. 

The primary target audience comprises operations architects, technical founders, and enterprise executives who demand real-time telemetry, zero-latency workflows, and uncompromised precision. The experience is designed to evoke absolute operational control, computational velocity, and unshakeable architectural stability. 

Visual characteristics include:
- Deep obsidian and slate foundations rather than pure black voids (`#000000` is strictly avoided to preserve chromatic depth).
- Electric Indigo anchors enterprise authority and core product structure, while Reactive Cyber Cyan acts as a luminous operational beacon for AI triggers, telemetry pings, and dynamic callouts.
- High-definition 1px structural framing throughout Bento layouts, replacing heavy solid drop shadows with ultra-subtle atmospheric dark-field glows and tonal card nesting.

## Colors

The color palette is engineered for prolonged operational focus, high data contrast, and crisp hierarchy between structural chrome and automated intelligence signals.

### Core Roles & Usage Principles
- **Canvas & Surface Tiering:** The root canvas rests on `obsidian-base` (`#060c18`). Elevated modules and Bento containers sit on `obsidian-card` (`#0f172a`), with flyouts, tooltips, and secondary layers elevated to `obsidian-surface` (`#111827`). Pure black (`#000000`) is explicitly prohibited.
- **The 10% Cyan Halo Rule:** `secondary_color_hex` (`#38bdf8`) functions strictly as a directional beacon—AI agent triggers, live telemetry pings, active cursor states, and key conversions. It must never occupy more than 10% of any viewport to preserve visual sharpness and intentionality.
- **State Semantics:** System health, active Webhook listeners, and successful Stripe payouts utilize `accent-emerald` (`#10b981`). Error payloads, terminated agent threads, and destructive confirmations trigger `accent-destructive` (`#ef4444`). Complex multi-agent workflow splits leverage `tertiary_color_hex` (`#7c3aed`).
- **Interactive Inversion:** In dark mode, primary interactive buttons utilize high-luminance cyan surfaces paired with dark background typography (`#060c18`) for immediate visual hierarchy.

## Typography

Typography relies entirely on the geometric neutrality and tall x-height of **Inter**. Tracking is tuned tightly across large scales to lend headlines an authoritative, engineered density, while body scales maintain open tracking and balanced leading for rapid scanning of operational dashboards.

- **Display & Section Anchors:** Display and headline levels require strong optical weights (`700` and `800`) with negative tracking (`-0.02em` to `-0.03em`) to reinforce tactical command branding.
- **Data & Metric Display:** Analytical data values, Stripe balances, Supabase latency readouts, and CRM conversion metrics use `title-lg` or `headline-md` rendered with tabular numerals (`font-feature-settings: 'tnum' 1, 'cv05' 1`) to eliminate layout jitter during real-time streaming updates.
- **Reading Constraints:** Technical documentation, CRM event histories, and system notifications must adhere strictly to a line measure between `65ch` and `75ch` (`max-w-3xl`) to protect scanning rhythm.

## Layout & Spacing

The spatial architecture is driven by a rigid 8px grid (sub-divided to 4px for granular micro-alignments such as status dots, pill badges, and input paddings).

### Layout System
- **Grid Architecture:** Multi-column Bento Grid structure using 12 fluid columns desktop, collapsing to 2 columns on tablet, and single-column stacked blocks on mobile. Maximum content width is capped at `1400px` (`max-w-7xl`), centered within the viewport.
- **Horizontal Margins:** Mobile viewports enforce `margin-sm` (`16px`), transitioning smoothly to `margin` (`32px`) beyond `1024px`.
- **Gutters & Gaps:** Bento modules and cards maintain a persistent `gutter` of `24px` (`gap-6`) desktop and `16px` (`gap-4`) mobile.
- **Component Padding Rhythm:** Standard command cards use `space-lg` (`24px`). Compact data tiles and inner metrics cards use `space-md` (`16px`). Hero command centers use `space-xl` (`32px`).

## Elevation & Depth

Visual hierarchy is maintained via a hybrid strategy of **Tonal Layering**, **Crisp 1px Boundaries**, and **Atmospheric Dark-Field Luminescence**. Traditional skeuomorphic cast shadows and unconstrained neobrutalist drop blocks are avoided.

### Surface Tiers
- **Tier 0 (Baseplate):** `#060c18`. Non-interactive main layout background.
- **Tier 1 (Bento Container / Default Card):** `#0f172a` wrapped in a crisp `1px solid #334155` border. Shadow: `0 1px 2px rgba(2, 6, 23, 0.62), 0 10px 26px rgba(2, 6, 23, 0.5)`.
- **Tier 2 (Elevated Command Card / Active Focus):** `#111827` bordered with `#334155`. Shadow: `0 2px 6px rgba(2, 6, 23, 0.66), 0 16px 38px rgba(2, 6, 23, 0.56)`.
- **Tier 3 (Modals / Flyouts / Command Palettes):** `#0f172a` backed by `backdrop-filter: blur(12px)`. Shadow: `0 4px 12px rgba(2, 6, 23, 0.72), 0 24px 56px rgba(8, 47, 73, 0.42)`.

### Ambient Halos & Interaction Depth
- **The Micro-Lift Rule:** Interactive containers and active cards elevate `-2px` on the Y-axis (`-translate-y-0.5`) across a `200ms ease-out` transition curve.
- **Reactive Glow:** Hover states across primary interactive units activate a low-saturation atmospheric cyan aura: `0 6px 18px rgba(2, 6, 23, 0.6), 0 18px 38px rgba(14, 165, 233, 0.18)`.

## Shapes

The geometric framework balances technical rigor with modern ergonomics through balanced rounding tokens:

- **Interactive Core (Buttons, Inputs, Selects):** Standard controls use `rounded.md` (`6px`) for clean, engineered boundary edges.
- **Modular Cards & Bento Cells:** Standard cards and operational surfaces utilize `rounded.lg` (`8px`) or `rounded.xl` (`12px`), maintaining optical harmony between outer frame borders and internal content grids.
- **Status Pills, Tags, and Identity Badges:** Strictly `9999px` (`rounded-full`) to immediately contrast functional status chips against rectilinear data grids.
- **Borders:** Fixed at uniform `1px` strokes. Thickened borders are forbidden except on active keyboard-navigation focus rings (`2px` solid `#38bdf8` offset by `2px`).

## Components

### Buttons
- **Primary Cyber CTA:** Built on a solid `#38bdf8` fill with high-contrast `#060c18` text, font weight `600`, height `40px`, and padding `10px 20px`. Hover triggers a brightness shift to `#22d3ee`, a `-2px` micro-lift, and an ambient cyan halo.
- **Secondary Authority Button:** Bordered in `1px solid #334155` over an `rgba(15, 23, 42, 0.6)` surface with `#e2e8f0` text. Hover transitions the border to `#4f46e5` with background saturation increase.
- **Destructive Action:** Low-alpha red tint `rgba(239, 68, 68, 0.1)` with `#ef4444` border and text. Hover deepens to solid `#ef4444` with white text.

### Cards & Bento Modules
- Constructed with `#0f172a` fill, `1px solid #334155` perimeter, and `rounded-xl` (`12px`) geometry.
- Cards feature a clear two-part structural anatomy:
  1. *Header Bar:* Icon container (rounded `6px` with subtle indigo/cyan backdrop), Title (`title-sm`), and live state badge.
  2. *Data Core:* High-contrast metrics accompanied by sparklines, logs, or agent orchestration controls.

### Status Pills & Identity Badges
- Pill-shaped (`rounded-full`), padding `4px 10px`, text `label-sm`.
- **Live / 24/7 Automation:** `bg-emerald-500/10` with `text-emerald-400` and an animated `4px` emerald pulsing dot.
- **Agent Active / Syncing:** `bg-sky-500/10` with `text-sky-400` and a `4px` cyan status beacon.
- **Enterprise / Protocol Badge:** `bg-indigo-500/10` with `text-indigo-400` and structural `1px` border `border-indigo-500/20`.

### Form Controls & Inputs
- Fixed height `40px`, padding `8px 12px`, background `#0f172a`, border `1px solid #334155`, text `#e2e8f0`, placeholder `#64748b`.
- Focus state invokes a crisp `2px` focus ring using `#38bdf8` with an offset of `2px` over `#060c18`.
- Inset shadow: `inset 0 1px 2px rgba(2, 6, 23, 0.6)`.

### Checkboxes & Radios
- Size `16px x 16px`, `rounded` (`4px` for checkboxes, `full` for radios).
- Resting state uses `#0f172a` fill with `1px solid #334155`. Checked state triggers `#4f46e5` fill with a crisp white checkmark and subtle indigo glow.

### Lists & Data Streams
- Streamed table rows and agent activity logs feature `48px` minimum height, delimited by `1px solid rgba(51, 65, 85, 0.5)` dividers.
- Hover states across table rows apply a transient background shift to `rgba(255, 255, 255, 0.02)`. Monospace details (API keys, run IDs, latency counts) utilize `code-sm` styling.